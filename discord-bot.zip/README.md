# discord-bot
Using discord.js to make a for fun discord bot and learn/practice some more programming

Current (unimplemented) plans
- User Profiles that include basic info and "fun" stats
